alert(" externaljs  isloading")
console.log("js is working ")